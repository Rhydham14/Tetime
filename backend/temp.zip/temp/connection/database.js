const mongoose = require('mongoose');

// Replace <username>, <password>, <cluster>, and <dbname> with your MongoDB Atlas credentials
const uri = 'mongodb+srv://rhydhambhalodia:CT42je0mke40VirR@cluster0.iychvgy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0&ssl=true';

mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch(err => console.error('Error connecting to MongoDB Atlas:', err));
